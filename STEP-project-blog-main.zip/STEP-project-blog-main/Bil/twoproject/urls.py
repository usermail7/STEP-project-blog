
from django.urls import path
from . import views

urlpatterns = [
    path('',views.posts),
    path('main/',views.main),
    path('blog/',views.blog),
    path('forme', views.forMe),
]
