from django.shortcuts import render
from twoproject.models import Post
from django.http import HttpResponse
# Create your views here.
def posts(request):
    posts = Post.objects.all()
    return render(request,'Bil/post_list.html', {'posts':posts})

def main(arg):
    return HttpResponse('Главная страница')

def blog(arg):
    return  HttpResponse('Блог')

def forMe(arg):
    return HttpResponse('Про себя')
